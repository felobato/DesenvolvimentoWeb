public abstract class Poliedro extends Figuras3D
{
	double altura;
	
	public Poliedro (double altura)
	{
		this.altura = altura;
	}
}