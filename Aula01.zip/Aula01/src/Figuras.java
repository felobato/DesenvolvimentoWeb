public abstract class Figuras
{
	public abstract double area();
	public abstract double perimetro();
	public double diagonal() {
		return 0;
	}
}